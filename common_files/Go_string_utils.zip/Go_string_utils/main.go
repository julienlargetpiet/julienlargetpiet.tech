package main

import (
  "fmt"
  //"reflect"
  "os"
  "bufio"
)

func fast_diff2(file1 *string, file2 *string, sep *string) string {
  var dataa string
  var datab string
  var comp bool = true
  var rtn_str string = ""
  filea, err := os.Open(*file1) 
  if err != nil {
    return ""
  }
  defer filea.Close()
  scannera := bufio.NewScanner(filea)
  fileb, err := os.Open(*file2) 
  if err != nil {
    return ""
  }
  defer fileb.Close()
  scannerb := bufio.NewScanner(fileb)
  for comp && scannerb.Scan() {
    datab = scannerb.Text()
    scannera.Scan()
    dataa = scannera.Text()
    for datab != dataa && scannera.Scan() {
      rtn_str = rtn_str + dataa + *sep + "- \n"
      dataa = scannera.Text()
    }
    comp = (datab == dataa)
    if comp {
      rtn_str = rtn_str + dataa + *sep + datab + "\n"
    } else {
      rtn_str = rtn_str + *sep + "+ " + datab + "\n"
    }
  }
  for scannerb.Scan() {
    datab = scannerb.Text()
    rtn_str = rtn_str + *sep + "+ " + datab + "\n"
  }
  //if comp {
    //rtn_str = rtn_str + dataa + *sep + "- " + "\n"
    for scannera.Scan() {
      dataa = scannera.Text()
      rtn_str = rtn_str + dataa + *sep + "- " + "\n"
    }
  //}
  return rtn_str
}

func main() {
  //var x int32 = 234
  //var rtn_str string
  //rtn_str = Int32ToString(&x)
  //fmt.Println(rtn_str)
  //var x string = "234"
  //rtn_val := StringToInt32(x)
  //fmt.Println(rtn_val)
  file1 := "file2.txt"
  file2 := "file2.txt"
  sep := " | "
  x := fast_diff2(&file1, &file2, &sep)
  fmt.Println(x)
}



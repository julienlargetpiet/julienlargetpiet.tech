package main

import (
  "fmt"
)


func main() {
  //var x int32 = 234
  //var rtn_str string
  //rtn_str = Int32ToString(&x)
  //fmt.Println(rtn_str)
  var x string = "234"
  rtn_val := StringToInt32(x)
  fmt.Println(rtn_val)
}



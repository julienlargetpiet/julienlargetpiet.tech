x = 0
rslt = 1

for (i in 1:10) {
  rslt = rslt + (x ** (2 * i) / factorial(2 * i)) * ((-1) ** i)
  print((x ** (2 * i) / factorial(2 * i)))
  #print(rslt)
}

print(rslt)
print(cos(x))

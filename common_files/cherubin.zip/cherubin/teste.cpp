#include "abstraction5.h"

int main() {
  std::string x = "4.6";
  std::string x2 = "6.2";
  std::string teste = "0.11";
  std::string teste2 = "0.112";
  bool out = is_greaterabstraction(teste, teste2);
  std::cout << out << "\n";
  out = is_greaterabstraction(teste2, teste);
  std::cout << out << "\n";
  return 0;
};



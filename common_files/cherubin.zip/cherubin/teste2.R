x = 45.8
new_x = x %% (2 * pi) 
rslt = new_x
cnt = 3

for (i in 1:10) {
  rslt = rslt + ((new_x ** cnt) / factorial(cnt)) * ((-1) ** i)
  print((new_x ** cnt) / factorial(cnt) * ((-1) ** i))
  print(cnt)
  cnt = cnt + 2
}

print(rslt)
print(sin(x))

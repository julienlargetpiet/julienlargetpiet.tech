x = 0.92
rslt = x
cnt = 3
cnt2 = 0
divider = 0
divided1 = 0
divided2 = 0

for (i in 1:9) {
  divided1 = x ** cnt
  cnt2 = cnt
  cnt2 = cnt2 - 2
  divided2 = cnt2
  cnt2 = cnt2 - 2
  while (cnt2 > 1) {
    divided2 = divided2 * cnt2
    cnt2 = cnt2 - 2
  }
  divider = cnt
  cnt2 = cnt - 1
  while (cnt2 > 0) {
    divider = divider * cnt2
    cnt2 = cnt2 - 2
  }
  #print(paste("divided1: ", divided1))
  #print(paste("divided2: ", divided2))
  #print(paste("divided mult: ", divided2 * divided1))
  #print(paste("divider: ", divider))
  rslt = rslt + (divided1 * divided2) / divider   
  print(paste("rslt: ", (divided1 * divided2) / divider))
  cnt = cnt + 2
}

print(rslt)
print((pi / 2) - rslt)
print(acos(x))




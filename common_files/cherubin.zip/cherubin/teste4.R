x = 1
rslt = pi
mltval = 2 ** 0.5 * (1 + x) ** 0.5
cnt = 3
cnt2 = 0
divider = 0
divided1 = 0
divided2 = 0

for (i in 1:9) {
  
}

print(rslt)
print((pi / 2) - rslt)
print(acos(x))


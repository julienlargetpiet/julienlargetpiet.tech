x = 0.9
rslt = x
ref_cnt = 3
cnt = 0
divided1 = 0
divided2 = 0
divider1 = 0
divider2 = 0
cur_rslt2 = 0
cur_rslt1 = 0
cur_rsltf = 0

for (i in 1:10) {
  divided2 = x ** ref_cnt
  divider2 = ref_cnt
  cur_rslt2 = divided2 / divider2
  cnt = ref_cnt - 2
  divided1 = cnt
  if (cnt > 1) {
    cnt = cnt - 2
    while (cnt > 1) {
      divided1 = divided1 * cnt
      cnt = cnt - 2
    }
  }
  cnt = ref_cnt - 1
  divider1 = cnt
  cnt = cnt - 2
  while (cnt != 0) {
    divider1 = divider1 * cnt
    cnt = cnt - 2
  }
  cur_rslt1 = divided1 / divider1
  cur_rsltf = cur_rslt2 * cur_rslt2
  rslt = rslt + cur_rsltf
  ref_cnt = ref_cnt + 2
  print(paste("divided1: ", divided1))
  print(paste("divider1: ", divider1))
  print(paste("divided2: ", divided2))
  print(paste("divider2: ", divider2))
}

print(rslt)
print(asin(x))
#print(pi / 4 - rslt)
#print(asin(1-x))


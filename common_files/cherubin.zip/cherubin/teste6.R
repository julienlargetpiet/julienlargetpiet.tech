x = 0.87
rslt = x
cnt = 3
divided = 0
divider = 0
fct = 0

for (i in 1:10) {
  divided = x ** cnt
  divider = cnt
  fct = divided / divider
  print(paste("fct ", fct))
  if (i %% 2 != 0) {
    rslt = rslt - fct
  } else {
    rslt = rslt + fct
  }
  cnt = cnt + 2
}

print(rslt)
print(atan(x))

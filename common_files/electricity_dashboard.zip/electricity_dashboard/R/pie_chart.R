pie_chart <- function(country_var){
  if (!(is.na(match(x = country_var, table = pre_elec_data_pivoted$country)))){
    data <- pre_elec_data_pivoted[country == country_var, ]
    data <- data[year == max(data$year), ]
    ggplot(data = data, mapping = aes(fill = reorder(type, twh), y = "", x = twh)) + 
          geom_col() + 
          coord_polar(theta = "x", start = 0) +
          scale_fill_manual(values = elec_color_vec) +
          theme_minimal() +
          theme(legend.position = "bottom",
          legend.text = element_text(size = 11)) +
          labs(fill = "type", x = "terawatthour") 
  }else{
    ggplot(data = data.frame("type" = "NA", "twh" = 1), 
          mapping = aes(
                       fill = type,
                       area = twh,
                       label = type
                       )) +
          geom_treemap() +
          geom_treemap_text(color = "black", place = "center", size = 15) +
          scale_fill_manual(values = "white") +
          theme_minimal() +
          theme(legend.position = "bottom", legend.text = element_text(size = 11))
  }
}

